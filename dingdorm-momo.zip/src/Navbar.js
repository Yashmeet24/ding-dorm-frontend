import { Link } from 'react-router-dom';

const navbar = () => {
    return ( 
        <div className="navbar">
            <div className="dashboard">
                <img className="dashboard-icon" src={require('./images/dashboard-solid-24.png')} alt="dashboard icon" />
                <h4><Link to={/dashboard} className="dashboard-title">Dashboard</Link></h4>
            </div>
            <div className="CleaningRequest">
                <img className="CleaningRequest-icon" src={require('./images/dashboard-solid-24.png')} alt="CleaningRequest icon" />
                <h4><Link to={/CleaningRequest} className="CleaningRequest-title">Request for Cleaning</Link></h4>
            </div>
            <div className="RoomStatistics">
                <img className="RoomStatistics-icon" src={require('./images/dashboard-solid-24.png')} alt="RoomStatistics icon" />
                <h4><Link to={/dashboard} className="RoomStatistics-title">Room Statistics</Link></h4>
            </div>
            <div className="Feedback">
                <img className="Feedback-icon" src={require('./images/dashboard-solid-24.png')} alt="Feedback icon" />
                <h4><Link to={/dashboard} className="Feedback-title">Feedback</Link></h4>
            </div>
        </div>
     );
}
 
export default navbar;