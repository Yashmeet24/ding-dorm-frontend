const homePage = () => {
    return ( 

        <div className="navbar ">
            <Navbar/>
        </div>


     );
}
 
export default homePage;