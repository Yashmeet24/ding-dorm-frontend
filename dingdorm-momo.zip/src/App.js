import LoginPage from "./LoginPage";
import { BrowserRouter as Router , Route, Switch } from "react-router-dom";
import signUp from "./signUp";
import dashboard from "./dashboard";

function App() {
  return (
    <div className="App">
        <LoginPage/>
  <Router>
    <Switch>
      <Route exact path="/logIn" Component={LoginPage}/>
      <Route exact path="/signIn" Component={signUp}/>
      <Route exact path="/dashboard" Component={dashboard}/>
        {/* <Route index element={<Home />} /> */}
        {/* <Route path="contact" element={<Contact />} />
        <Route path="*" element={<NoPage />} /> */}
    </Switch>
  </Router>
  </div>

  );
}

export default App;
